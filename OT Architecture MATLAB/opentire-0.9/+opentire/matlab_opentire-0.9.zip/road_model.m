classdef road_model
%ROAD_MODEL Base class for road surface model

methods(Abstract)
  compute_contact
end % methods

end % classdef

